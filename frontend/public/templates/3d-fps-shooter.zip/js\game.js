// Main Game Logic
let scene, camera, renderer;
let player, weapon;
let enemies = [];
let score = 0;
let isPaused = false;
let gameOver = false;

// Initialize Three.js
function init() {
    // Scene
    scene = new THREE.Scene();
    scene.background = new THREE.Color(CONFIG.world.skyColor);
    scene.fog = new THREE.Fog(CONFIG.world.skyColor, 1, 100);

    // Camera
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

    // Renderer
    const canvas = document.getElementById('gameCanvas');
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(50, 50, 50);
    directionalLight.castShadow = true;
    scene.add(directionalLight);

    // Ground
    const groundGeometry = new THREE.PlaneGeometry(CONFIG.world.size, CONFIG.world.size);
    const groundMaterial = new THREE.MeshPhongMaterial({ color: CONFIG.world.groundColor });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Add some obstacles
    createObstacles();

    // Player
    player = new Player(scene, camera);

    // Weapon
    weapon = new Weapon();

    // Controls
    setupGameControls();

    // Start enemy spawning
    setInterval(spawnEnemy, CONFIG.enemy.spawnInterval);

    // Window resize
    window.addEventListener('resize', onWindowResize);

    // Start game loop
    animate();
}

function createObstacles() {
    const boxGeometry = new THREE.BoxGeometry(2, 2, 2);
    const boxMaterial = new THREE.MeshPhongMaterial({ color: 0x8B4513 });

    for (let i = 0; i < 20; i++) {
        const box = new THREE.Mesh(boxGeometry, boxMaterial);
        box.position.set(
            Math.random() * 80 - 40,
            1,
            Math.random() * 80 - 40
        );
        box.castShadow = true;
        box.receiveShadow = true;
        scene.add(box);
    }
}

function spawnEnemy() {
    if (gameOver || enemies.length >= CONFIG.enemy.maxEnemies) return;

    const angle = Math.random() * Math.PI * 2;
    const distance = 30 + Math.random() * 20;
    const position = new THREE.Vector3(
        Math.cos(angle) * distance,
        0,
        Math.sin(angle) * distance
    );

    const enemy = new Enemy(scene, position);
    enemies.push(enemy);
    updateEnemyCount();
}

function setupGameControls() {
    document.addEventListener('keydown', (e) => {
        if (e.code === 'Escape') {
            togglePause();
        }
    });

    // Shooting
    document.addEventListener('click', () => {
        if (gameOver || isPaused) return;

        const shot = weapon.fire();
        if (shot) {
            checkHit();
        }
    });
}

function checkHit() {
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);

    enemies.forEach((enemy, index) => {
        if (enemy.isDead) return;

        const intersects = raycaster.intersectObject(enemy.mesh);
        if (intersects.length > 0 && intersects[0].distance < CONFIG.weapon.range) {
            const killed = enemy.takeDamage(CONFIG.weapon.damage);
            if (killed) {
                score += 100;
                document.getElementById('score').textContent = score;
                enemies.splice(index, 1);
                updateEnemyCount();
            }
        }
    });
}

function updateEnemyCount() {
    document.getElementById('enemies').textContent = enemies.length;
}

function togglePause() {
    isPaused = !isPaused;
    document.getElementById('pauseMenu').classList.toggle('hidden', !isPaused);
}

function resumeGame() {
    isPaused = false;
    document.getElementById('pauseMenu').classList.add('hidden');
}

function restartGame() {
    location.reload();
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

function animate() {
    requestAnimationFrame(animate);

    if (gameOver || isPaused) return;

    // Update player
    player.update();

    // Update enemies
    enemies.forEach(enemy => {
        enemy.update(camera.position);

        if (enemy.canAttack(camera.position)) {
            const damage = enemy.attack();
            const dead = player.takeDamage(damage);
            if (dead) {
                endGame();
            }
        }
    });

    // Render
    renderer.render(scene, camera);
}

function endGame() {
    gameOver = true;
    document.getElementById('finalScore').textContent = score;
    document.getElementById('gameOverMenu').classList.remove('hidden');
}

// Start game
init();
