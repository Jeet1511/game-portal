// Game Configuration
const CONFIG = {
    canvas: {
        width: 800,
        height: 600
    },
    player: {
        width: 40,
        height: 40,
        speed: 5,
        jumpPower: 12,
        gravity: 0.5,
        color: '#FF6B6B'
    },
    platform: {
        color: '#4ECDC4',
        borderColor: '#2C3E50'
    },
    coin: {
        size: 15,
        color: '#FFD700',
        value: 10
    },
    enemy: {
        width: 35,
        height: 35,
        speed: 2,
        color: '#E74C3C'
    },
    levels: [
        {
            platforms: [
                { x: 0, y: 550, width: 800, height: 50 },
                { x: 200, y: 450, width: 150, height: 20 },
                { x: 450, y: 350, width: 150, height: 20 },
                { x: 100, y: 250, width: 150, height: 20 },
                { x: 550, y: 200, width: 150, height: 20 }
            ],
            coins: [
                { x: 250, y: 400 },
                { x: 500, y: 300 },
                { x: 150, y: 200 },
                { x: 600, y: 150 }
            ],
            enemies: [
                { x: 300, y: 410, direction: 1, minX: 200, maxX: 350 },
                { x: 500, y: 310, direction: 1, minX: 450, maxX: 600 }
            ]
        },
        {
            platforms: [
                { x: 0, y: 550, width: 800, height: 50 },
                { x: 100, y: 480, width: 120, height: 20 },
                { x: 300, y: 400, width: 120, height: 20 },
                { x: 500, y: 320, width: 120, height: 20 },
                { x: 650, y: 240, width: 120, height: 20 },
                { x: 400, y: 160, width: 150, height: 20 }
            ],
            coins: [
                { x: 150, y: 430 },
                { x: 350, y: 350 },
                { x: 550, y: 270 },
                { x: 700, y: 190 },
                { x: 475, y: 110 }
            ],
            enemies: [
                { x: 150, y: 440, direction: 1, minX: 100, maxX: 220 },
                { x: 350, y: 360, direction: 1, minX: 300, maxX: 420 },
                { x: 550, y: 280, direction: 1, minX: 500, maxX: 620 }
            ]
        }
    ]
};
