// Main Game Logic
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Set canvas size
canvas.width = CONFIG.canvas.width;
canvas.height = CONFIG.canvas.height;

// Auto-focus canvas
canvas.focus();
canvas.addEventListener('click', () => canvas.focus());

// Game state
let score = 0;
let lives = 3;
let currentLevel = 0;
let gameRunning = true;

// Game objects
let player;
let platforms = [];
let coins = [];
let enemies = [];

// Keyboard input
const keys = {};
window.addEventListener('keydown', (e) => {
    keys[e.key] = true;
    if (e.key === 'r' || e.key === 'R') {
        restartGame();
    }
});
window.addEventListener('keyup', (e) => keys[e.key] = false);

// Initialize level
function loadLevel(levelIndex) {
    const levelData = CONFIG.levels[levelIndex];

    // Create platforms
    platforms = levelData.platforms.map(p =>
        new Platform(p.x, p.y, p.width, p.height)
    );

    // Create coins
    coins = levelData.coins.map(c =>
        new Coin(c.x, c.y)
    );

    // Create enemies
    enemies = levelData.enemies.map(e =>
        new Enemy(e.x, e.y, e.direction, e.minX, e.maxX)
    );

    // Reset player
    player = new Player(50, 450);
}

// Update UI
function updateUI() {
    document.getElementById('score').textContent = score;
    document.getElementById('lives').textContent = lives;
    document.getElementById('level').textContent = currentLevel + 1;
}

// Draw background
function drawBackground() {
    // Sky gradient
    const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    gradient.addColorStop(0, '#87CEEB');
    gradient.addColorStop(1, '#E0F6FF');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Clouds
    ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
    ctx.beginPath();
    ctx.arc(150, 80, 30, 0, Math.PI * 2);
    ctx.arc(180, 80, 40, 0, Math.PI * 2);
    ctx.arc(210, 80, 30, 0, Math.PI * 2);
    ctx.fill();

    ctx.beginPath();
    ctx.arc(550, 120, 35, 0, Math.PI * 2);
    ctx.arc(585, 120, 45, 0, Math.PI * 2);
    ctx.arc(620, 120, 35, 0, Math.PI * 2);
    ctx.fill();
}

// Check level completion
function checkLevelComplete() {
    const allCoinsCollected = coins.every(coin => coin.collected);
    if (allCoinsCollected) {
        gameRunning = false;
        document.getElementById('levelScore').textContent = score;
        document.getElementById('levelComplete').classList.remove('hidden');
    }
}

// Next level
function nextLevel() {
    document.getElementById('levelComplete').classList.add('hidden');
    currentLevel++;

    if (currentLevel >= CONFIG.levels.length) {
        // Game won!
        alert(`Congratulations! You completed all levels!\nFinal Score: ${score}`);
        currentLevel = 0;
        score = 0;
        lives = 3;
    }

    loadLevel(currentLevel);
    updateUI();
    gameRunning = true;
    gameLoop();
}

// Player death
function playerDied() {
    lives--;
    updateUI();

    if (lives <= 0) {
        gameRunning = false;
        document.getElementById('finalScore').textContent = score;
        document.getElementById('gameOver').classList.remove('hidden');
    } else {
        player.reset(50, 450);
    }
}

// Restart game
function restartGame() {
    document.getElementById('gameOver').classList.add('hidden');
    document.getElementById('levelComplete').classList.add('hidden');
    score = 0;
    lives = 3;
    currentLevel = 0;
    loadLevel(currentLevel);
    updateUI();
    gameRunning = true;
    gameLoop();
}

// Game loop
function gameLoop() {
    if (!gameRunning) return;

    // Clear and draw background
    drawBackground();

    // Draw platforms
    platforms.forEach(platform => platform.draw(ctx));

    // Draw and update coins
    coins.forEach(coin => {
        coin.draw(ctx);
        score += coin.checkCollision(player);
    });

    // Draw and update enemies
    enemies.forEach(enemy => {
        enemy.draw(ctx);
        enemy.update();
        if (enemy.checkCollision(player)) {
            playerDied();
        }
    });

    // Update and draw player
    const playerDead = player.update(keys, platforms);
    if (playerDead) {
        playerDied();
    }
    player.draw(ctx);

    // Update UI
    updateUI();

    // Check level completion
    checkLevelComplete();

    requestAnimationFrame(gameLoop);
}

// Start game
loadLevel(currentLevel);
updateUI();
gameLoop();
