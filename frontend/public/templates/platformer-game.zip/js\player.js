// Player Class
class Player {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.width = CONFIG.player.width;
        this.height = CONFIG.player.height;
        this.velocityX = 0;
        this.velocityY = 0;
        this.speed = CONFIG.player.speed;
        this.jumpPower = CONFIG.player.jumpPower;
        this.gravity = CONFIG.player.gravity;
        this.isJumping = false;
        this.color = CONFIG.player.color;
    }

    draw(ctx) {
        // Body
        ctx.fillStyle = this.color;
        ctx.fillRect(this.x, this.y, this.width, this.height);

        // Eyes
        ctx.fillStyle = 'white';
        ctx.fillRect(this.x + 10, this.y + 10, 8, 8);
        ctx.fillRect(this.x + 22, this.y + 10, 8, 8);

        // Pupils
        ctx.fillStyle = 'black';
        ctx.fillRect(this.x + 13, this.y + 13, 3, 3);
        ctx.fillRect(this.x + 25, this.y + 13, 3, 3);

        // Smile
        ctx.strokeStyle = 'black';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(this.x + this.width / 2, this.y + 25, 10, 0, Math.PI);
        ctx.stroke();
    }

    update(keys, platforms) {
        // Horizontal movement
        if (keys['ArrowLeft']) this.velocityX = -this.speed;
        else if (keys['ArrowRight']) this.velocityX = this.speed;
        else this.velocityX = 0;

        // Jump
        if (keys['ArrowUp'] && !this.isJumping) {
            this.velocityY = -this.jumpPower;
            this.isJumping = true;
        }

        // Apply gravity
        this.velocityY += this.gravity;
        this.y += this.velocityY;
        this.x += this.velocityX;

        // Boundary check
        if (this.x < 0) this.x = 0;
        if (this.x + this.width > CONFIG.canvas.width) {
            this.x = CONFIG.canvas.width - this.width;
        }

        // Platform collision
        this.isJumping = true;
        platforms.forEach(platform => {
            if (this.x < platform.x + platform.width &&
                this.x + this.width > platform.x &&
                this.y + this.height > platform.y &&
                this.y + this.height < platform.y + platform.height &&
                this.velocityY > 0) {
                this.y = platform.y - this.height;
                this.velocityY = 0;
                this.isJumping = false;
            }
        });

        // Fall off screen
        if (this.y > CONFIG.canvas.height) {
            return true; // Player died
        }
        return false;
    }

    reset(x, y) {
        this.x = x;
        this.y = y;
        this.velocityX = 0;
        this.velocityY = 0;
        this.isJumping = false;
    }
}
